<div class="container-fluid pt-3">
    <footer class="py-3 bg-dark text-white-50">
        <div class="text-center">
            <div class="d-flex flex-column">
                <div>
                    <a class="small px-2" href="index.php">Home</a>
                    <a class="small px-2" href="supportme.php">Support Us!</a>
                </div>
                <small class="pt-2">Copyright &copy; BOEY Media 2020</p>
            </div>
        </div>
    </footer>
</div>